'''
Mighty Maxims: Short & Memorable Quotations.
Project: https://github.com/soft9000/DoctorQuote
Paperback: https://www.amazon.com/dp/B09H9DV8KV
Video: https://youtube.com/shorts/gJOylaramnc
Website: https://MightyMaxims.com

>>> import MightyMaxims
>>> MightyMaxims.get_quote()
>>> MightyMaxims.submission_info()

'''

__all__ = ['GetQuote','get_quote','submission_info']


def get_quote():
    ''' Display a random Maxim. Feel free to
    send yours to DoctorQuote@gmail.com .'''
    import MightyMaxims.GetRandom as app
    app.get_random()


def GetQuote():
    ''' Display a random Maxim. Feel free to
    send yours to DoctorQuote@gmail.com .'''
    get_quote()


def submission_info():
    """ How to share your quotations."""
    print("""
Project Overview
================
"Mighty Maxims" are short & memorable
sayings -- now uniquely numbered
for eternity!

Database Submissions
--------------------
Doctor Quote's Database has over
250,000 quotations. Reviewed and
subjectively marked as either
'good', 'bad', 'ugly', and 'best'
quotations have been added to the
collection since 1978.

Maxim Submissions
-----------------
Doctor Quote reviews all quotations for
potential inclusion into the MightyMaxims
package when emailed to DoctorQuote@gmail.com.

Notes:
=====
() Quotations should be under 500 characters.
() Mighty Maxims are under 150 Characters.
() The best submissions are shared in English.
() Self-quoting is okay!
() Submission implies consent to share.
() Nexus is MightyMaxims.com

Keep on 'Quotin!

p.s. Mighty Maxims now use Doctor Quote's 
globally-unique database identifiers.
Because the database is massively larger,
any Maxim's number is often greater
than the total number of MightyMaxims.

""")

