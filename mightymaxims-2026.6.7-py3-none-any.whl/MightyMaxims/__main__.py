'''
Mighty Maxims: Short & Memorable Quotations.
Project: https://github.com/soft9000/DoctorQuote
Paperback: https://www.amazon.com/dp/B09H9DV8KV
Video: https://youtube.com/shorts/gJOylaramnc
Website: https://MightyMaxims.com

>>> import MightyMaxims
>>> MightyMaxims.get_quote()
>>> MightyMaxims.submission_info()

'''

try:
    import MightyMaxims.GetRandom as app
    app.get_random()
except Exception as ex:
    print(ex,"Beware the Wumpus ...")

